﻿using Microsoft.EntityFrameworkCore;

namespace Albums.Modelos
{
    // Clase que representa el contexto de base de datos para la aplicación
    public class DBContext : DbContext
    {
        // DbSet que representa la colección de álbumes en la base de datos
        public DbSet<Album> Albums { get; set; }

        // Método llamado automáticamente cuando se configura el contexto de la base de datos
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Configuración para usar una base de datos en memoria llamada "BDRazor"
            optionsBuilder.UseInMemoryDatabase("BDRazor");
        }
    }
}


